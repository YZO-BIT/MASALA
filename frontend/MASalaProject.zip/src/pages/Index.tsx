
import { useState } from "react";
import Header from "@/components/Header";
import RecipeForm, { RecipeFormData } from "@/components/RecipeForm";
import RecipeCard, { Recipe } from "@/components/RecipeCard";
import RecipeDetails from "@/components/RecipeDetails";
import AIAgentsProcessing from "@/components/AIAgentsProcessing";
import { toast } from "sonner";

// Mock API response - in a real app this would come from your backend
const mockFetchRecipes = (formData: RecipeFormData): Promise<Recipe[]> => {
  // Simulate API delay
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([
        {
          id: "1",
          title: "Vegetable Stir-Fry",
          summary: "A colorful mix of sauteed vegetables in a savory sauce.",
          image: "https://images.unsplash.com/photo-1512058564366-18510be2db19?q=80&w=2072&auto=format",
          readyInMinutes: 25,
          ingredients: [
            "2 cups mixed vegetables (bell peppers, broccoli, carrots)",
            "1 cup rice",
            "2 cloves garlic, minced",
            "1 tbsp ginger, grated",
            "3 tbsp soy sauce",
            "1 tbsp sesame oil"
          ],
          steps: [
            "Cook rice according to package instructions.",
            "Heat oil in a wok or large frying pan over high heat.",
            "Add garlic and ginger, stir for 30 seconds until fragrant.",
            "Add vegetables and stir fry for 5-7 minutes until tender-crisp.",
            "Add soy sauce and toss to combine.",
            "Serve vegetables over rice and drizzle with sesame oil."
          ],
          nutrition: {
            calories: "320 kcal",
            protein: "6g",
            carbs: "45g",
            fat: "9g"
          }
        },
        {
          id: "2",
          title: "Chickpea Salad",
          summary: "A refreshing salad with chickpeas, cucumber, tomatoes, and herbs.",
          image: "https://images.unsplash.com/photo-1529059997568-3d847b1154f0?q=80&w=2070&auto=format",
          readyInMinutes: 15,
          ingredients: [
            "1 can (15 oz) chickpeas, drained and rinsed",
            "1 cucumber, diced",
            "1 cup cherry tomatoes, halved",
            "1/2 red onion, finely chopped",
            "1/2 cup feta cheese, crumbled",
            "2 tbsp olive oil",
            "1 tbsp lemon juice",
            "Salt and pepper to taste"
          ],
          steps: [
            "Combine chickpeas, cucumber, tomatoes, onion, and feta in a large bowl.",
            "In a small bowl, whisk together olive oil, lemon juice, salt, and pepper.",
            "Pour dressing over salad and toss to combine.",
            "Refrigerate for at least 30 minutes before serving to allow flavors to meld."
          ],
          nutrition: {
            calories: "280 kcal",
            protein: "12g",
            carbs: "28g",
            fat: "14g"
          }
        },
        {
          id: "3",
          title: "Stuffed Bell Pepper",
          summary: "A bell pepper stuffed with a savory blend of rice, vegetables, and cheese.",
          image: "https://images.unsplash.com/photo-1575853121743-60c24f0a7502?q=80&w=2070&auto=format",
          readyInMinutes: 45,
          ingredients: [
            "4 bell peppers, tops removed and seeded",
            "1 cup cooked rice",
            "1/2 lb ground beef or turkey (optional)",
            "1 onion, diced",
            "2 cloves garlic, minced",
            "1 zucchini, diced",
            "1 cup cherry tomatoes, halved",
            "1 cup shredded cheese",
            "2 tbsp olive oil",
            "1 tsp Italian herbs",
            "Salt and pepper to taste"
          ],
          steps: [
            "Preheat oven to 375°F (190°C).",
            "If using meat, brown it in a skillet with onions and garlic.",
            "Mix cooked rice, meat mixture, zucchini, tomatoes, half the cheese, olive oil, and herbs.",
            "Season with salt and pepper.",
            "Stuff the bell peppers with the mixture.",
            "Place peppers in a baking dish with a little water at the bottom.",
            "Cover with foil and bake for 30 minutes.",
            "Remove foil, sprinkle with remaining cheese, and bake for 10 more minutes."
          ],
          nutrition: {
            calories: "320 kcal",
            protein: "15g",
            carbs: "30g",
            fat: "16g"
          }
        }
      ]);
    }, 1500);
  });
};

const Index = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [showAgentsProcessing, setShowAgentsProcessing] = useState(false);

  const handleSearch = async (formData: RecipeFormData) => {
    setIsLoading(true);
    setShowResults(false);
    setShowAgentsProcessing(true);
    
    try {
      // This would be your actual API call
      const data = await mockFetchRecipes(formData);
      setRecipes(data);
      
      // Show success toast
      toast.success("Recipes found based on your criteria!");
    } catch (error) {
      console.error("Error fetching recipes:", error);
      toast.error("Failed to find recipes. Please try again.");
      setShowAgentsProcessing(false);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAgentsComplete = () => {
    setShowAgentsProcessing(false);
    setShowResults(true);
  };

  const handleRecipeClick = (recipe: Recipe) => {
    setSelectedRecipe(recipe);
    setIsDetailsOpen(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="food-pattern-header py-8">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-6">
            <h1 className="text-4xl md:text-5xl font-bold mb-2 text-foreground">Dish Suggestions</h1>
          </div>
        </div>
      </div>
      
      <main className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row gap-8">
          <div className="md:w-1/3">
            <RecipeForm onSearch={handleSearch} />
          </div>
          
          <div className="md:w-2/3">
            {isLoading && (
              <div className="flex justify-center my-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
              </div>
            )}

            {showAgentsProcessing && !isLoading && (
              <AIAgentsProcessing 
                isVisible={showAgentsProcessing} 
                onComplete={handleAgentsComplete} 
              />
            )}

            {showResults && !isLoading && (
              <div>
                <h2 className="text-2xl font-bold mb-6">Recommended Recipes</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {recipes.map((recipe) => (
                    <RecipeCard 
                      key={recipe.id}
                      recipe={recipe}
                      onClick={() => handleRecipeClick(recipe)}
                    />
                  ))}
                </div>
              </div>
            )}

            {!showResults && !showAgentsProcessing && !isLoading && (
              <div className="flex flex-col items-center justify-center h-full animate-fade-in">
                <div className="welcome-illustration w-full bg-secondary/20 rounded-2xl p-6 md:p-8 relative overflow-hidden">
                  <div className="flex flex-col md:flex-row items-center md:items-end gap-4 md:gap-8">
                    <div className="grandma-image w-40 md:w-56 lg:w-64 h-auto z-10">
                      <img 
                        src="/lovable-uploads/baf7b1aa-87f3-43c4-9917-c08f104d8bb9.png" 
                        alt="Grandmother chef" 
                        className="w-full h-auto"
                      />
                    </div>
                    
                    <div className="speech-bubble bg-white rounded-2xl p-4 md:p-6 relative mb-4 md:mb-10 shadow-md max-w-xs">
                      <div className="absolute w-4 h-4 bg-white transform rotate-45 -left-2 bottom-4 md:bottom-8"></div>
                      <p className="text-xl md:text-2xl font-medium text-foreground">
                        What would you like to have today?
                      </p>
                    </div>
                  </div>
                  
                  <div className="food-icons absolute top-4 right-4 md:top-8 md:right-12 flex gap-3">
                    <span className="text-4xl">🍅</span>
                    <span className="text-4xl">🥕</span>
                    <span className="text-4xl">🍄</span>
                  </div>
                  
                  <div className="food-icons absolute bottom-4 right-8 md:bottom-8 md:right-24 flex gap-3">
                    <span className="text-4xl">🍉</span>
                    <span className="text-4xl">🥦</span>
                  </div>
                  
                  <p className="text-xl text-center text-foreground mt-6 max-w-md mx-auto">
                    Fill in your preferences on the left to discover delicious recipes tailored just for you!
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>

      <RecipeDetails 
        recipe={selectedRecipe} 
        isOpen={isDetailsOpen}
        onClose={() => setIsDetailsOpen(false)}
      />
    </div>
  );
};

export default Index;
