
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const RecipeForm = ({ onSearch }: { onSearch: (data: RecipeFormData) => void }) => {
  const [formData, setFormData] = useState<RecipeFormData>({
    dietaryRestriction: "",
    allergies: "",
    cookingTime: 30,
    mealType: "",
    cuisine: "",
    fridgeItems: ""
  });

  const handleChange = (name: string, value: string | number) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(formData);
  };

  return (
    <div className="w-full max-w-md mx-auto">
      <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-sm p-6">
        <h2 className="text-2xl font-bold mb-6 text-foreground">Find dishes to cook</h2>
        
        <div className="space-y-5">
          <div className="space-y-2">
            <Label htmlFor="dietaryRestriction" className="text-base">Dietary restrictions</Label>
            <Select 
              value={formData.dietaryRestriction} 
              onValueChange={value => handleChange("dietaryRestriction", value)}
            >
              <SelectTrigger id="dietaryRestriction" className="border-input bg-white">
                <SelectValue placeholder="Select restriction" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                <SelectItem value="vegetarian">Vegetarian</SelectItem>
                <SelectItem value="vegan">Vegan</SelectItem>
                <SelectItem value="pescatarian">Pescatarian</SelectItem>
                <SelectItem value="keto">Keto</SelectItem>
                <SelectItem value="paleo">Paleo</SelectItem>
                <SelectItem value="gluten-free">Gluten-Free</SelectItem>
                <SelectItem value="dairy-free">Dairy-Free</SelectItem>
                <SelectItem value="low-carb">Low Carb</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="allergies" className="text-base">Allergies</Label>
            <Input 
              id="allergies" 
              placeholder="Enter allergies"
              className="border-input bg-white" 
              value={formData.allergies}
              onChange={e => handleChange("allergies", e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="cookingTime" className="text-base">Cooking time (minutes)</Label>
            <Select 
              value={formData.cookingTime.toString()} 
              onValueChange={value => handleChange("cookingTime", parseInt(value))}
            >
              <SelectTrigger id="cookingTime" className="border-input bg-white">
                <SelectValue placeholder="30" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="15">15</SelectItem>
                <SelectItem value="30">30</SelectItem>
                <SelectItem value="45">45</SelectItem>
                <SelectItem value="60">60</SelectItem>
                <SelectItem value="90">90</SelectItem>
                <SelectItem value="120">120</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="mealType" className="text-base">Meal type</Label>
            <Select 
              value={formData.mealType} 
              onValueChange={value => handleChange("mealType", value)}
            >
              <SelectTrigger id="mealType" className="border-input bg-white">
                <SelectValue placeholder="Select meal type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="breakfast">Breakfast</SelectItem>
                <SelectItem value="lunch">Lunch</SelectItem>
                <SelectItem value="dinner">Dinner</SelectItem>
                <SelectItem value="dessert">Dessert</SelectItem>
                <SelectItem value="snack">Snack</SelectItem>
                <SelectItem value="appetizer">Appetizer</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="fridgeItems" className="text-base">What's in your fridge?</Label>
            <Textarea 
              id="fridgeItems" 
              placeholder="Enter ingredients separated by commas" 
              className="min-h-20 border-input bg-white"
              value={formData.fridgeItems}
              onChange={e => handleChange("fridgeItems", e.target.value)}
            />
          </div>
        </div>

        <div className="mt-6">
          <Button 
            type="submit" 
            className="w-full bg-primary hover:bg-primary/90 text-white py-2 rounded-md"
          >
            Search
          </Button>
        </div>
      </form>
    </div>
  );
};

export interface RecipeFormData {
  dietaryRestriction: string;
  allergies: string;
  cookingTime: number;
  mealType: string;
  cuisine: string;
  fridgeItems: string;
}

export default RecipeForm;
